@extends('users.layouts.master')

@section('content')
    <main>
        <!-- Banner Start -->
        <section class="banner v1">
            <div class="container">
                <div class="banner-content">
                    <div class="section-title v1">
                        <h2 class="big-title">
                            Introducing with Blockchain Payment Platform</h2>
                        <p class="title-para">Unlock the potential of instant, low-cost and cross-chain
                            blockchain
                            <br> payments with our fincatch network
                        </p>
                    </div>
                    <ul class="all-btns">
                        <li><a href="#" class="link-anime v1 round-border-sm icon-1">Sign me up</a></li>
                        <li><a href="#" class="link-anime v2 round-border-sm icon-1">Sign me up</a></li>
                    </ul>
                        <div class="banner-img wow animate__zoomIn" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <img src="{{ asset('user/assets/img/banner/v1/img-2.png') }}" alt="img">
                    </div>
                </div>
            </div>
            <div class="bg-shap-1" data-background="{{ asset('user/assets/img/banner/v1/shap-1.svg') }}"></div>
            <div class="bg-shap-2" data-background="{{ asset('user/assets/img/banner/v1/shap-2.svg') }}"></div>
            <div class="bg-shap-3" data-background="{{ asset('user/assets/img/banner/v1/img-1.png') }}"></div>
        </section>
        <!-- Banner End -->
        <!-- Core Feature Start -->
        <section class="core-feature v1 pt-sm-50 pb-sm-50 pt-md-70 pb-md-70 pt-xl-100 pb-xl-100 pt-130 pb-130">
            <div class="container">
                <div class="section-title-white v1">
                    <div class="title-left-right-end">
                        <div class="w-80-15">
                            <h2 class="big-title">Designed for financial inclusion, <br> transparency.</h2>
                        </div>
                        <div class="core-feature-img">
                            <img src="{{ asset('user/assets/img/core-feature/v1/core-feature-img.png') }}" alt="core-feature">
                        </div>
                    </div>
                    <h5 class="sub-title v1">NEXT GENERATION MONEY</h5>
                </div>
                <ul class="core-list-card">
                    <li class="wow animate__fadeInUp" data-wow-offset="200" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <div class="core-list-text">
                            <h2 class="big-title">Built for Global payments</h2>
                            <p class="title-para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                        <div class="core-list-img">
                            <img src="{{ asset('user/assets/img/core-feature/v1/list-card-1.png') }}" alt="list-card">
                        </div>
                    </li>
                    <li class="wow animate__fadeInUp" data-wow-offset="200" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <div class="core-list-text">
                            <h2 class="big-title">Corporate Settlement</h2>
                            <p class="title-para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                        <div class="core-list-img">
                            <img src="{{ asset('user/assets/img/core-feature/v1/list-card-2.png') }}" alt="list-card">
                        </div>
                    </li>
                    <li class="wow animate__fadeInUp" data-wow-offset="200" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <div class="core-list-text">
                            <h2 class="big-title">Local Business</h2>
                            <p class="title-para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                        <div class="core-list-img">
                            <img src="{{ asset('user/assets/img/core-feature/v1/list-card-3.png') }}" alt="list-card">
                        </div>
                    </li>
                    <li class="wow animate__fadeInUp" data-wow-offset="200" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <div class="core-list-text">
                            <h2 class="big-title">Internet of Money</h2>
                            <p class="title-para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                        <div class="core-list-img">
                            <img src="{{ asset('user/assets/img/core-feature/v1/list-card-4.png') }}" alt="list-card">
                        </div>
                    </li>
                </ul>

            </div>
        </section>
        <!-- Core Feature End -->
        <!-- Benefits Start -->
        <section class="benefits v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
            <div class="container">
                <div class="section-title v1">
                    <div class="title-left-right-center">
                        <div class="w-80-15">
                            <h2 class="big-title">Fast easy and low cost payments for all </h2>
                        </div>
                        <a href="#" class="link-anime v1 round-border-sm icon-1">Sign me up</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.4s"
                        data-wow-duration="0.8s">
                        <div class="benefits-card">
                            <div class="benefits-img">
                                <img src="{{ asset('user/assets/img/benefits/benefits-img-1.png') }}" alt="benefits-img">
                            </div>
                            <h3 class="title">With e-Money, you can enjoy immediate finality and settlement, as well
                                as near-zero transaction fees.</h3>
                            <p class="para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.6s"
                        data-wow-duration="0.8s">
                        <div class="benefits-card">
                            <div class="benefits-img">
                                <img src="{{ asset('user/assets/img/benefits/benefits-img-2.png') }}" alt="benefits-img">
                            </div>
                            <h3 class="title">Join us in revolutionizing the way we send money, and experience the
                                future of payments with the fincatch</h3>
                            <p class="para">Provide people across the globe easy access to financial services
                                worldwide. Send money globally for near.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-shap-1" data-background="{{ asset('user/assets/img/benefits/bg-shap.svg') }}"></div>
        </section>
        <!-- Benefits End -->
        <!-- Video Box Start -->
        <section class="video-box v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
            <div class="container">
                <div class="section-title-white v1">
                    <h2 class="big-title">Secure the e-Money Network by staking Next Generation <span
                            class="color-blue">(NGM)</span> token.</h2>
                </div>
                    <div class="video-card-box">
                    <button class="play-btn v1 venobox" data-vbtype="video" data-maxwidth="800px" data-autoplay="true"
                        data-href="https://youtu.be/itIpz_Vn3hU?si=ZAJVdN7irElA62Bu&amp;t=5"><i
                            class="my-icon icon-play-t"></i></button>
                    <img src="{{ asset('user/assets/img/ngm-token/video-code.jpg') }}" alt="video-code">
                </div>
                <div class="earn-staking">
                    <div class="content-left">
                        <h6 class="small-title">STAKING YIELD <span class="staking-vale">28.56%</span></h6>
                        <h2 class="title">Earn Staking Rewards</h2>
                    </div>
                    <span class="earn-staking-link">
                        <a href="#">Learn more about Tokens</a>
                    </span>
                </div>
            </div>
            <div class="bg-shap-1" data-background="{{ asset('user/assets/img/ngm-token/shap-1.svg') }}"></div>
        </section>
        <!-- Video Box End -->
        <!-- Key Benefits Start -->
        <section class="key-benefits v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
            <div class="slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-1.png') }}" alt="slide-img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-2.jpg') }}" alt="slide-img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-3.png') }}" alt="slide-img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-4.jpg') }}" alt="slide-img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-5.png') }}" alt="slide-img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                            <div class="slide-img">
                            <img src="{{ asset('user/assets/img/key-benefits/v1/slide-img-2.jpg') }}" alt="slide-img">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Key Benefits End -->
        <!-- Recent Blogs START -->
        <section class="recent-blogs v1 pb-sm-50 pb-130 pb-md-70 pb-lg-100">
            <div class="container">
                <div class="section-title v1">
                    <div class="title-left-right-center">
                        <div class="w-lg-80-15">
                            <h5 class="sub-title v4">NEXT GENERATION MONEY</h5>
                        </div>
                        <button class="link-anime v3 round-border-full">View all</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.1s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-1.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Published on October 4, 2022</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.3s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-2.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Discover Our Blockchain Payment Platform</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.5s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-3.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Unwinding EEUR issuance and Boosting.</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.1s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-4.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Transforming Payments with Blockchain</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.3s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-5.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Get Started with Blockchain Payments</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.5s"
                        data-wow-duration="0.8s">
                        <div class="recent-blog-card">
                            <div class="recent-blog-card-img">
                                <a href="#">
                                    <img src="{{ asset('user/assets/img/recent-blogs/v1/recent-blog-img-6.jpg') }}"
                                        alt="recent-blog-img">
                                </a>
                            </div>
                            <div class="recent-blog-card-contant">
                                <h6 class="small-title">Join the Blockchain Payment Revolution</h6>
                                <h4 class="title"><a href="#">Introducing Our Blockchain-Based Payment Platform</a>
                                </h4>
                                <a href="#" class="read-more v1">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Recent Blogs End -->
        <!-- Partners Start -->
        <section class="partners v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
            <div class="container">
                <div class="featured-section v1">
                    <div class="section-title v1">
                        <div class="title-left-right-center">
                            <div class="w-lg-80-15">
                                <h5 class="sub-title v2">AS FEATURED IN</h5>
                            </div>
                            <ul class="slider-btns">
                                <li>
                                    <button class="prev-btn"><i class="my-icon icon-arrow-left"></i></button>
                                </li>
                                <li>
                                    <button class="next-btn"><i class="my-icon icon-arrow-right"></i></button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <h5 class="small-text">Published on Investing.com</h5>
                                <h3 class="title">How e-Money's eEUR Stable coin Mitigates Risk of Single Currency
                                    Exposure</h3>
                            </div>
                            <div class="swiper-slide">
                                <h5 class="small-text">Published on Bitcoinist</h5>
                                <h3 class="title">e-Money Set to Bring European Stablecoins to Avalanche Ecosystem
                                </h3>
                            </div>
                            <div class="swiper-slide">
                                <h5 class="small-text">Published on Yahoo Finance</h5>
                                <h3 class="title">Becomes The First Stablecoin To Be Listed On Osmosis AMM
                                    Decentralized Exchange</h3>
                            </div>
                            <div class="swiper-slide">
                                <h5 class="small-text">Published on BTCmanager</h5>
                                <h3 class="title">e-Money's Interest- Bearing Assets Are Evolution of Stablecoins
                                </h3>
                            </div>
                            <div class="swiper-slide">
                                <h5 class="small-text">Published on Bitcoinist</h5>
                                <h3 class="title">e-Money Set to Bring European Stablecoins to Avalanche Ecosystem
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="seleced-section v1">
                    <div class="section-title v1">
                        <div class="title-left-right-center">
                            <div class="w-lg-80-15">
                                <h5 class="sub-title v2">SELECTED PARTNERS</h5>
                            </div>
                            <ul class="slider-btns">
                                <li>
                                    <button class="prev-btn"><i class="my-icon icon-arrow-left"></i></button>
                                </li>
                                <li>
                                    <button class="next-btn"><i class="my-icon icon-arrow-right"></i></button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="seleced-card">
                                    <div class="partner-logo">
                                        <img src="{{ asset('user/assets/img/partners/v1/logo-1.svg') }}" alt="logo">
                                    </div>
                                    <h6 class="para">The leading security-focused ranking platform to analyze and
                                        monito</h6>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="seleced-card">
                                    <div class="partner-logo">
                                        <img src="{{ asset('user/assets/img/partners/v1/logo-2.svg') }}" alt="logo">
                                    </div>
                                    <h6 class="para">Cosmos is an ever-expanding ecosystem of interoperable and
                                        sovereign blockchain apps and services.</h6>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="seleced-card">
                                    <div class="partner-logo">
                                        <img src="{{ asset('user/assets/img/partners/v1/logo-3.svg') }}" alt="logo">
                                    </div>
                                    <h6 class="para">The leading security-focused ranking platform to analyze and
                                    </h6>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="seleced-card">
                                    <div class="partner-logo">
                                        <img src="{{ asset('user/assets/img/partners/v1/logo-4.svg') }}" alt="logo">
                                    </div>
                                    <h6 class="para">Cosmos is an ever-expanding ecosystem of interoperable and
                                        sovereign blockchain apps and services.</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-shap-1" data-background="{{ asset('user/assets/img/partners/v1/shap-1.svg') }}"></div>
        </section>
        <!-- Partners End -->
    </main>
@endsection
