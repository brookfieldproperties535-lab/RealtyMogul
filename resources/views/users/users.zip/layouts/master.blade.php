<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from itcroctheme.com/fincatch/fincatch-html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 08:14:29 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Fincatch HTML5 Template">
    <meta name="description" content="Fincatch HTML5 Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>RealtyMogul.com™ | Real Estate Crowdfunding & Investing</title>

    <!-- Apple Favicon -->
    <link rel="apple-touch-icon" href="user/assets/img/logo/favicon.svg">

    <!-- All Device Favicon -->
    <link rel="icon" href="user/assets/img/logo/icon.svg">

    <!-- Icon -->
    <link rel="stylesheet" href="user/assets/all-icons/myicon.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="user/assets/css/bootstrap.min.css">

    <!-- Animate Css -->
    <link rel="stylesheet" href="user/assets/css/plugins/animate.min.css">

    <!-- Swiper Css -->
    <link rel="stylesheet" href="user/assets/css/plugins/swiper-bundle.min.css">

    <!-- Venobox Css -->
    <link rel="stylesheet" href="user/assets/css/plugins/venobox.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="user/assets/css/style.css">

    <!-- Responsive -->
    <link rel="stylesheet" href="user/assets/css/responsive.css">

</head>

<body>

    <div id="main-wrapper">
        <header>
            <!-- Manu Bar Start -->
            <div class="menu-bar v1">
                <div class="container">
                    <div class="menu-content">
                        <div class="menu-logo">
                            <a href="/"><img src="user/assets/img/logo/logo.svg" alt="logo"></a>
                        </div>
                        <nav class="main-menu">
                            <ul>
                                <li class="active">
                                    <a href="{{ route('users.investment-opportunities') }}">MarketPlace</a>
                                </li>
                                <li class="has-dropdown">
                                    <a href="#">1031 EXCHANGE</a>
                                    <ul>
                                        <li><a href="{{ route('users.knowledge-center') }}">KNOWLEDGE CENTER</a></li>
                                    </ul>
                                </li>
                                <li><a href="{{ route('users.rm-communities') }}">RM COMMUNITITES</a></li>
                                <li class="has-dropdown">
                                    <a href="#">REITS</a>
                                    <ul>
                                        <li><a href="{{ route('users.income-reits') }}">INCOME REITS</a></li>
                                        <li><a href="{{ route('users.growth-reits') }}">GROWTH REITS</a></li>
                                        <li><a href="{{ route('users.why-reits') }}">WHY REITS</a></li>
                                    </ul>
                                </li>
                                <li class="has-dropdown">
                                    <a href="#">RESEARCH</a>
                                    <ul>
                                        <li><a href="{{ route('users.due-diligence-process') }}">DUE DELIGENCE PROCESS</a></li>
                                        <li><a href="{{ route('users.investment-options') }}">INVESTMEN OPTIONS</a></li>
                                        <li><a href="{{ route('users.1031-exchange') }}">1031 EXCHANGE</a></li>
                                        <li><a href="{{ route('users.private-credit') }}">PRIVATE CREDIT</a></li>
                                        <li><a href="{{ route('users.why-commercial-real-estate') }}">WHY COMMERCIAL REAL ESTATE</a></li>
                                        <li><a href="{{ route('users.knowledge-center') }}">KNOWLEDGE CENTER</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                        <div class="menu-right">
                            <ul class="right-menur-btns">
                                <li>
                                    <button class="search-option-open">
                                        <i class="my-icon icon-search-status"></i>
                                    </button>
                                </li>
                                <li>
                                    <button><i class="my-icon icon-user"></i></button>
                                </li>
                            </ul>
                            <div class="mobile-menu-bar">
                                <div class="mobile-content">
                                    <ul class="social-link">
                                        <li><a href="#"><i class="my-icon icon-facebook"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-instagram"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-twitter"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Manu Bar End -->
        </header>

        @yield('content')

        <footer>
            <div class="footer-section v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
                <div class="staking-reward">
                    <div class="container">
                        <div class="staking-reward-content">
                            <h2 class="title">Earn Staking Rewards</h2>
                            <a href="#" class="link-anime v4 round-border-sm icon-1">Sign me up</a>
                        </div>
                    </div>
                </div>
                <div class="info-footer">
                    <div class="container">
                        <div class="info-footer-content">
                            <div class="footer-widget">
                                <div class="footer-widget-content">
                                    <div class="footer-logo">
                                        <a href="/"><img src="user/assets/img/logo/logo-1.svg"
                                                alt="Logo"></a>
                                    </div>
                                    <div class="social-profile">
                                        <h6 class="small-title">Social Profile</h6>
                                        <ul class="social-link">
                                            <li><a href="#"><i class="my-icon icon-facebook"></i></a></li>
                                            <li><a href="#"><i class="my-icon icon-instagram"></i></a></li>
                                            <li><a href="#"><i class="my-icon icon-twitter"></i></a></li>
                                            <li><a href="#"><i class="my-icon icon-linkedin-in"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Companay</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">e-Books</a></li>
                                        <li><a href="#">Guides</a></li>
                                        <li><a href="#">Templates</a></li>
                                        <li><a href="#">Paycatch</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Features</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">e-money</a></li>
                                        <li><a href="#">Local Business</a></li>
                                        <li><a href="#">Corporate</a></li>
                                        <li><a href="#">Internet Money</a></li>
                                        <li><a href="#">staking ecosystem</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Guides</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">e-Books</a></li>
                                        <li><a href="#">Guides</a></li>
                                        <li><a href="#">Templates</a></li>
                                        <li><a href="#">Paycatch</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <div class="footer-widget-content">
                                    <div class="address-link-line">
                                        <h5 class="title">e-Money A/S <br> Hammerensgade 1, 2, 1267, Copenhagen,
                                            Denmark
                                        </h5>
                                        <ul class="link-line">
                                            <li>
                                                <a href="#">FAQ <i class="my-icon icon-arrow-right"></i></a>
                                            </li>
                                            <li>
                                                <a href="#">Legal Notices <i
                                                        class="my-icon icon-arrow-right"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-main v1">
                    <div class="container">
                        <div class="footer-main-content">
                            <h6 class="text">Copyright © 2024 all right reserved</h6>
                            <h6 class="text">Designed by <a href="#">ITcroc</a></h6>
                        </div>
                    </div>
                </div>
                <div class="bg-shap-1" data-background="user/assets/img/footer/v1/bg-shap-1.svg"></div>
                <div class="shap-1" data-background="user/assets/img/footer/v1/shap-1.svg"></div>
            </div>
            <div class="back-to-top">
                <a href="#">
                    <i class="my-icon icon-arrow-up"></i>
                </a>
            </div>
        </footer>
    </div>

    <!-- jQuery -->
    <script src="user/assets/js/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap -->
    <script src="user/assets/js/bootstrap.min.js"></script>

    <!-- Anime JS -->
    <script src="user/assets/js/plugins/anime.min.js"></script>

    <!-- Swiper JS -->
    <script src="user/assets/js/plugins/swiper-bundle.min.js"></script>

    <!-- Venobox JS -->
    <script src="user/assets/js/plugins/venobox.min.js"></script>

    <!-- WOW JS -->
    <script src="user/assets/js/plugins/wow.min.js"></script>

    <!-- Index -->
    <script src="user/assets/js/index.js"></script>
</body>


<!-- Mirrored from itcroctheme.com/fincatch/fincatch-html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 08:15:36 GMT -->

</html>
