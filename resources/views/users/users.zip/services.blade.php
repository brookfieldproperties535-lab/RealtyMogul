<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from itcroctheme.com/fincatch/fincatch-html/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 08:19:40 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Fincatch HTML5 Template">
    <meta name="description" content="Fincatch HTML5 Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Fincatch - Banking, Finance And Fintech HTML Template</title>

    <!-- Apple Favicon -->
    <link rel="apple-touch-icon" href="assets/img/logo/favicon.svg">

    <!-- All Device Favicon -->
    <link rel="icon" href="assets/img/logo/icon.svg">

    <!-- Icon -->
    <link rel="stylesheet" href="assets/all-icons/myicon.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Animate Css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">

    <!-- Swiper Css -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">

    <!-- Venobox Css -->
    <link rel="stylesheet" href="assets/css/plugins/venobox.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Responsive -->
    <link rel="stylesheet" href="assets/css/responsive.css">

</head>

<body>

    <div id="main-wrapper">
        <header>
            <!-- Manu Bar Start -->
            <div class="menu-bar v1">
                <div class="container">
                    <div class="menu-content">
                        <div class="menu-logo">
                            <a href="index.html"><img src="assets/img/logo/logo.svg" alt="logo"></a>
                        </div>
                        <nav class="main-menu">
                            <ul>
                                <li class="has-dropdown">
                                    <a href="#">Home Page</a>
                                    <ul>
                                        <li><a href="index.html">Home 1</a></li>
                                        <li><a href="index-2.html">Home 2</a></li>
                                        <li><a href="index-3.html">Home 3</a></li>
                                        <li><a href="index-4.html">Home 4</a></li>
                                        <li><a href="index-5.html">Home 5</a></li>
                                        <li><a href="index-6.html">Home 6</a></li>
                                        <li><a href="index-7.html">Home 7</a></li>
                                        <li><a href="index-8.html">Home 8</a></li>
                                    </ul>
                                </li>
                                <li><a href="about.html">About</a></li>
                                <li class="has-dropdown">
                                    <a href="#">Pages</a>
                                    <ul>
                                        <li><a href="pricing.html">Pricing</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li><a href="career-opportunity.html">Career Opportunity</a></li>
                                        <li><a href="job-post.html">Job Post</a></li>
                                    </ul>
                                </li>
                                <li class="has-dropdown active">
                                    <a href="#">Services</a>
                                    <ul>
                                        <li class="active"><a href="services.html">Services</a></li>
                                        <li><a href="services-details.html">Services Details</a></li>
                                    </ul>
                                </li>
                                <li class="has-dropdown">
                                    <a href="#">Blog</a>
                                    <ul>
                                        <li><a href="blog.html">Blog</a></li>
                                        <li><a href="blog-details.html">Blog Details</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact us</a></li>
                            </ul>
                        </nav>
                        <div class="menu-right">
                            <ul class="right-menur-btns">
                                <li>
                                    <button class="siderbar-btns"><i class="my-icon icon-category"></i></button>
                                    <button class="mobile-btns"><i class="my-icon icon-category"></i></button>
                                </li>
                            </ul>
                            <div class="mobile-menu-bar">
                                <div class="mobile-content">
                                    <ul class="social-link">
                                        <li><a href="#"><i class="my-icon icon-facebook"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-instagram"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-twitter"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="siderbar-menu">
                                <div class="siderbar-header">
                                    <div class="canvas-logo">
                                        <a href="index.html"><img src="assets/img/logo/logo.svg" alt="logo"></a>
                                    </div>
                                    <button class="close-btn"><i class="my-icon icon-close"></i></button>
                                </div>
                                <div class="siderbar-body">
                                    <ul class="contact-list">
                                        <li>
                                            <h6>Office Address</h6>
                                            <p>123/A, Miranda City Likaoli <br> Prikano, Dope</p>
                                        </li>
                                        <li>
                                            <h6>Phone Number</h6>
                                            <p>+0989 7876 9865 9 <br> +(090) 8765 86543 85</p>
                                        </li>
                                        <li>
                                            <h6>Email Address</h6>
                                            <p>info@example.com <br>example.mail@hum.com</p>
                                        </li>
                                    </ul>
                                    <ul class="social-link">
                                        <li><a href="#"><i class="my-icon icon-facebook"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-instagram"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-twitter"></i></a></li>
                                        <li><a href="#"><i class="my-icon icon-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Manu Bar End -->
        </header>
        <main>
            <!-- Breadcum Start -->
            <section class="breadcum v1">
                <div class="container">
                    <div class="breadcum-content">
                        <h2>Service</h2>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li>Service</li>
                        </ul>
                    </div>
                </div>
                <div class="bg-shap-1" data-background="assets/img/breadcum/v1/bg-shap.html"></div>
                <div class="bg-shap-2" data-background="assets/img/breadcum/v1/img-1.html"></div>
                <div class="bg-shap-3" data-background="assets/img/breadcum/v1/img-2.html"></div>
            </section>
            <!-- Breadcum End -->
            <!-- Services Area Start-->
            <section class="service-area pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-7">
                            <div class="left-contant">
                                <div class="section-title v1">
                                    <h2 class="big-title">The complete banking solutions for everyone</h2>
                                    <p class="title-para">Sodales mauris quam faucibus scelerisque risus malesuada
                                        nulla. Cursus enim <br> quis elementum feugiat ut. Phasellus a viverra facilisis
                                        eu
                                        purus. Et risus magna <br> dis nisl nulla sed diam.</p>
                                </div>
                                <ul class="all-btns">
                                    <li>
                                        <a href="#" class="link-anime v1 round-border-sm icon-1">Get Started</a>
                                    </li>
                                </ul>
                                <div class="small-img">
                                    <img alt="small-card-img" src="assets/img/service-area/small-card-img.html">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="right-contant">
                                <div class="big-img">
                                    <img alt="big-card-img" src="assets/img/service-area/big-card-img.html">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Services Area End-->
            <!-- Why Fincatch Start -->
            <section class="why-fincatch pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
                <div class="container">
                    <div class="row align-content-center">
                        <div class="col-xl-7">
                            <div class="left-contant">
                                <div class="section-title-white v7">
                                    <h2 class="big-title">Financing to keep you <br> moving forward</h2>
                                    <p class="title-para v1">Id nullam in pretium semper vel. Egestas diam eget vitae
                                        arcu at
                                        in. <br> Scelerisque pellentesque molestie enim luctus massa
                                        felis in eros. <br> Porta ac faucibus nulla est euismod dignissim donec arcu
                                        nunc.
                                    </p>
                                </div>
                                <ul class="features-list">
                                    <li><i class="my-icon icon-check"></i>
                                        <p class="features-item">Felis blandit enim ornare quis feugiat vel adipiscing.
                                            <br> Egestas
                                            iaculis in sapien risus luctus quis.
                                        </p>
                                    </li>
                                    <li><i class="my-icon icon-check"></i>
                                        <p class="features-item">Felis blandit enim ornare quis feugiat vel adipiscing.
                                            <br> Egestas
                                            iaculis in sapien risus luctus quis.
                                        </p>
                                    </li>
                                    <li><i class="my-icon icon-check"></i>
                                        <p class="features-item">Felis blandit enim ornare quis feugiat vel adipiscing.
                                            <br> Egestas
                                            iaculis in sapien risus luctus quis.
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-5">
                            <div class="right-contant">
                                <div class="big-img">
                                    <img alt="" src="assets/img/why-fincatch/big-img.html">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="section-title-center-white v1 pt-sm-50 pt-md-70 pt-xl-100 pt-130">
                        <p class="sub-title v14">Why Fincatch</p>
                        <h2 class="big-title v1">Every features you need to <br> grow your business</h2>
                        <p class="title-para v2">Elementum vitae consequat at luctus mauris pellentesque.</p>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xl-3 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.1s"
                            data-wow-duration="0.8s">
                            <div class="why-fincatch-card">
                                <div class="card-icon"><i class="my-icon icon-dollar"></i></div>
                                <h2 class="card-title">Instant payouts</h2>
                                <p class="card-para">Ut amet rutrum est morbi egestas praesent at volutpat felis velit
                                    auctor
                                    egestas vulputate feugiat.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.3s"
                            data-wow-duration="0.8s">
                            <div class="why-fincatch-card">
                                <div class="card-icon"><i class="my-icon icon-red-flag"></i></div>
                                <h2 class="card-title">Free transfers</h2>
                                <p class="card-para">Ut amet rutrum est morbi egestas praesent at volutpat felis velit
                                    auctor
                                    egestas vulputate feugiat.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.5s"
                            data-wow-duration="0.8s">
                            <div class="why-fincatch-card">
                                <div class="card-icon"><i class="my-icon icon-folder"></i></div>
                                <h2 class="card-title">businesses of all sizes</h2>
                                <p class="card-para">Ut amet rutrum est morbi egestas praesent at volutpat felis velit
                                    auctor
                                    egestas vulputate feugiat.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3 wow animate__fadeInUp" data-wow-offset="100" data-wow-delay="0.7s"
                            data-wow-duration="0.8s">
                            <div class="why-fincatch-card">
                                <div class="card-icon"><i class="my-icon icon-share"></i></div>
                                <h2 class="card-title">Access to capital</h2>
                                <p class="card-para">Ut amet rutrum est morbi egestas praesent at volutpat felis velit
                                    auctor
                                    egestas vulputate feugiat.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-slider-img">
                    <img src="assets/img/why-fincatch/bg-slider.html" alt="bg-slider">
                </div>
            </section>
            <!-- Why Fincatch End -->
            <!-- Box Image Content Start -->
            <section class="box-image-content v1 pt-sm-50 pt-md-70 pt-xl-100 pt-130">
                <div class="container">
                    <div class="main-image-content">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="left-content">
                                    <div class="section-title v1">
                                        <h2 class="big-title">Auto allocate <br> your taxes</h2>
                                        <p class="title-para">Ut in fermentum et nisl risus nec non. Auctor sit nisl
                                            <br>
                                            mattis
                                            lacus eget mauris odio ac. Volutpat eros tellus <br>viverra massa tempor
                                            integer
                                            a.
                                        </p>
                                        <ul class="all-btns mt-30">
                                            <li>
                                                <a href="#" class="link-anime v1 round-border-sm icon-1">Learn More</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="taxes-img">
                                    <img alt="taxes-image" src="assets/img/taxes-imgs/taxes-Image.html">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Box Image Content End -->
            <!-- Box Image Content Start -->
            <section class="box-image-content v2 pt-sm-50 pt-md-70 pt-xl-100 pt-130">
                <div class="container">
                    <div class="main-image-content">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="taxes-img">
                                    <img alt="taxes-image" src="assets/img/taxes-imgs/payments-image.html">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="left-content">
                                    <div class="section-title v1">
                                        <h2 class="big-title">Auto allocate <br> your taxes</h2>
                                        <p class="title-para">Ut in fermentum et nisl risus nec non. Auctor sit nisl
                                            <br>
                                            mattis
                                            lacus eget mauris odio ac. Volutpat eros tellus <br>viverra massa tempor
                                            integer
                                            a.
                                        </p>
                                        <ul class="all-btns mt-30">
                                            <li>
                                                <a href="#" class="link-anime v1 round-border-sm icon-1">Learn More</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Box Image Content End -->
            <!-- Box Image Content Start -->
            <section class="box-image-content v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
                <div class="container">
                    <div class="main-image-content">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="left-content">
                                    <div class="section-title v1">
                                        <h2 class="big-title">Auto allocate <br> your taxes</h2>
                                        <p class="title-para">Ut in fermentum et nisl risus nec non. Auctor sit nisl
                                            <br>
                                            mattis
                                            lacus eget mauris odio ac. Volutpat eros tellus <br>viverra massa tempor
                                            integer
                                            a.
                                        </p>
                                        <ul class="all-btns mt-30">
                                            <li>
                                                <a href="#" class="link-anime v1 round-border-sm icon-1">Learn More</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="taxes-img">
                                    <img alt="taxes-image" src="assets/img/taxes-imgs/money-image.html">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Box Image Content End -->
            <!-- Wallet Integrations Start -->
            <section class="wallet-integrations pb-50 pb-md-70 pb-lg-100 pb-xl-100 pb-xxl-130">
                <div class="container">
                    <div class="section-title-center v1">
                        <h2 class="big-title">Wallet Integrations</h2>
                        <p class="title-para">Urna diam malesuada vitae tristique elementum odio. In senectus <br>
                            pharetra nunc imperdiet eget. Etiam sagittis tincidunt sit <br> consectetur vel nibh nibh.
                        </p>
                    </div>
                    <div class="integrations-circle bg-cover-center"
                        data-background="assets/img/wallet-integrations/circle-shap.html">
                        <i class="my-icon icon-blot"></i>
                        <div class="pament-item-1 wow animate__zoomIn" data-wow-offset="100" data-wow-delay="0.1s"
                            data-wow-duration="0.8s">
                            <img src="assets/img/wallet-integrations/apple-pay.html" alt="apple-pay">
                        </div>
                        <div class="pament-item-2 wow animate__zoomIn" data-wow-offset="100" data-wow-delay="0.3s"
                            data-wow-duration="0.8s">
                            <img src="assets/img/wallet-integrations/paypal-pay.html" alt="paypal-pay">
                        </div>
                        <div class="pament-item-3 wow animate__zoomIn" data-wow-offset="100" data-wow-delay="0.5s"
                            data-wow-duration="0.8s">
                            <img src="assets/img/wallet-integrations/stripe-pay.html" alt="stripe-pay">
                        </div>
                        <div class="pament-item-4 wow animate__zoomIn" data-wow-offset="100" data-wow-delay="0.7s"
                            data-wow-duration="0.8s">
                            <img src="assets/img/wallet-integrations/wise-pay.html" alt="wise-pay">
                        </div>
                    </div>
                </div>
            </section>
            <!-- Wallet Integrations End -->
            <!-- Interested Our Team Start -->
            <section class="interested-our-team v1 pb-sm-50 pb-130 pb-md-70 pb-lg-100">
                <div class="container">
                    <div class="interested-team-card">
                        <div class="interested-team-content">
                            <div class="section-title v1">
                                <h2 class="big-title">Interested to join our team?</h2>
                                <p class="title-para">Natoque tellus aliquam aenean justo consequat semper adipiscing.
                                    <br>
                                    Facilisis vestibulum pretium ut viverra malesuada.
                                </p>
                            </div>
                            <a href="#" class="link-anime v1 icon-1 round-border-sm">View Open Positions</a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Interested Our Team End -->
        </main>
        <footer>
            <div class="footer-section v1 pt-sm-50 pb-sm-50 pt-130 pb-130 pt-md-70 pb-md-70 pt-lg-100 pb-lg-100">
                <div class="staking-reward">
                    <div class="container">
                        <div class="staking-reward-content">
                            <h2 class="title">Earn Staking Rewards</h2>
                            <a href="#" class="link-anime v4 round-border-sm icon-1">Sign me up</a>
                        </div>
                    </div>
                </div>
                <div class="info-footer">
                    <div class="container">
                        <div class="info-footer-content">
                            <div class="footer-widget">
                                <div class="footer-widget-content">
                                    <div class="footer-logo">
                                        <a href="index.html"><img src="assets/img/logo/logo-2.svg" alt="Logo"></a>
                                    </div>
                                    <div class="social-profile">
                                        <h6 class="small-title">Social Profile</h6>
                                        <ul class="social-link">
                                            <li><a href="#">
                                                    <div class="card-icon"><i class="my-icon icon-global"></i></div>
                                                </a></li>
                                            <li><a href="#"><i class="my-icon icon-instagram"></i></a></li>
                                            <li><a href="#"><i class="my-icon icon-twitter"></i></a></li>
                                            <li><a href="#"><i class="my-icon icon-linkedin-in"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Companay</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">e-Books</a></li>
                                        <li><a href="#">Guides</a></li>
                                        <li><a href="#">Templates</a></li>
                                        <li><a href="#">Paycatch</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Features</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">e-money</a></li>
                                        <li><a href="#">Local Business</a></li>
                                        <li><a href="#">Corporate</a></li>
                                        <li><a href="#">Internet Money</a></li>
                                        <li><a href="#">staking ecosystem</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Guides</h4>
                                <div class="footer-widget-content">
                                    <ul class="link-list">
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">e-Books</a></li>
                                        <li><a href="#">Guides</a></li>
                                        <li><a href="#">Templates</a></li>
                                        <li><a href="#">Paycatch</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footer-widget">
                                <div class="footer-widget-content">
                                    <div class="address-link-line">
                                        <h5 class="title">e-Money A/S <br> Hammerensgade 1, 2, 1267, Copenhagen, Denmark
                                        </h5>
                                        <ul class="link-line">
                                            <li>
                                                <a href="#">FAQ</a>
                                                <div class="my-icon icon-arrow-right"></div>
                                            </li>
                                            <li>
                                                <a href="#">Legal Notices</a>
                                                <div class="my-icon icon-arrow-right"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-main v1">
                    <div class="container">
                        <div class="footer-main-content">
                            <h6 class="text">Copyright © 2024 all right reserved</h6>
                            <h6 class="text">Designed by <a href="#">ITcroc</a></h6>
                        </div>
                    </div>
                </div>
                <div class="bg-shap-1" data-background="assets/img/footer/v1/bg-shap-1.svg"></div>
                <div class="shap-1" data-background="assets/img/footer/v1/shap-1.svg"></div>
            </div>
            <div class="back-to-top">
                <a href="#">
                    <i class="my-icon icon-arrow-up"></i>
                </a>
            </div>
        </footer>
    </div>

    <!-- jQuery -->
    <script src="assets/js/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Anime JS -->
    <script src="assets/js/plugins/anime.min.js"></script>

    <!-- Swiper JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>

    <!-- Venobox JS -->
    <script src="assets/js/plugins/venobox.min.js"></script>

    <!-- WOW JS -->
    <script src="assets/js/plugins/wow.min.js"></script>

    <!-- Index -->
    <script src="assets/js/index.js"></script>
</body>


<!-- Mirrored from itcroctheme.com/fincatch/fincatch-html/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 08:19:56 GMT -->
</html>